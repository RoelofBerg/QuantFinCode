#ifndef GUARD_utilities_h
#define GUARD_utilities_h

double max(double x, double y);
double min(double x, double y);
double bound(double a, double x, double b);
#endif