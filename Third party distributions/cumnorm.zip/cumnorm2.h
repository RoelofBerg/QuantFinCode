#ifndef GUARD_cumnorm2_h
#define GUARD_cumnorm2_h

#include "cumnorm1.h"
double bivarcumnorm(double x, double y, double rho);

#endif; 