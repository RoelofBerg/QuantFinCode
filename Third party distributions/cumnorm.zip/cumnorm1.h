#ifndef GUARD_cumnorm1_h
#define GUARD_cumnorm1_h

double cumnorm(double x);
double cumnorm6(double x);
double NPrime(double x );
double NPrimePrime(double x);
double CumNormInverse(double y);

#endif