#ifndef GUARD_cumnorm3_h
#define GUARD_cumnorm3_h

#include "cumnorm1.h"
#include "cumnorm2.h"
double trivarcumnorm(double x, double y, double z, double correl12, double correl13, double correl23);

#endif; 